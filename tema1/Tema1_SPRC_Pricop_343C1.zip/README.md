# Homework 1 SPRC

The rpc stubs are already built, but we you wanna rebuild them, run the
makefile. Don't run `rpcgen -a`. I use custom .cpp files and custom makefile.

## Build

```
$ make -f Makefile.auth

```


"Started making it. Had a breakdown. Bon appetite."
